# Peptide Docking Clean

Minimal version with Meeko, RDKit, Docker, and peptide JSON integration.